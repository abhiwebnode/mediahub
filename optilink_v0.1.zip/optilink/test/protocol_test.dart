import 'dart:convert';
import 'dart:typed_data';
import 'package:test/test.dart';

// We test the logic directly (pure Dart, no Flutter widgets needed)
// In the actual Flutter project these run with: flutter test

// ── Inline implementations for standalone testing ──────────────────────────
// (mirrors the real protocol files exactly)

enum FrameType { meta, data, end }

String sessionIdGenerate() {
  // deterministic for test
  return 'DEADBEEF';
}

bool sessionIdIsValid(String id) {
  return RegExp(r'^[0-9A-F]{8}$').hasMatch(id);
}

// Simple CRC32 for tests (matches the crc32 package output)
int crc32Compute(List<int> data) {
  int crc = 0xFFFFFFFF;
  for (final byte in data) {
    crc ^= byte;
    for (int j = 0; j < 8; j++) {
      if (crc & 1 == 1) {
        crc = (crc >> 1) ^ 0xEDB88320;
      } else {
        crc >>= 1;
      }
    }
  }
  return crc ^ 0xFFFFFFFF;
}

// ─── Chunker ───────────────────────────────────────────────────────────────

List<Uint8List> chunkSplit(Uint8List bytes, {int chunkSize = 800}) {
  final chunks = <Uint8List>[];
  int offset = 0;
  while (offset < bytes.length) {
    final end = offset + chunkSize < bytes.length
        ? offset + chunkSize
        : bytes.length;
    chunks.add(Uint8List.fromList(bytes.sublist(offset, end)));
    offset = end;
  }
  return chunks;
}

Uint8List? chunkReassemble(Map<int, Uint8List> chunks, int totalChunks) {
  for (int i = 0; i < totalChunks; i++) {
    if (!chunks.containsKey(i)) return null;
  }
  final buffer = BytesBuilder();
  for (int i = 0; i < totalChunks; i++) {
    buffer.add(chunks[i]!);
  }
  return buffer.toBytes();
}

// ─── Frame serialization (matches frame.dart) ─────────────────────────────

String buildMetaQr({
  required String sessionId,
  required String fileName,
  required int fileSize,
  required int chunkCount,
  required String sha256,
}) {
  return jsonEncode({
    't': 'M',
    's': sessionId,
    'fn': fileName,
    'fs': fileSize,
    'cc': chunkCount,
    'h': sha256,
  });
}

String buildDataQr({
  required String sessionId,
  required int chunkIndex,
  required int chunkCount,
  required Uint8List payload,
}) {
  final crc = crc32Compute(payload);
  return jsonEncode({
    't': 'D',
    's': sessionId,
    'i': chunkIndex,
    'c': chunkCount,
    'p': base64.encode(payload),
    'r': crc,
  });
}

Map<String, dynamic>? parseFrame(String raw) {
  try {
    final map = jsonDecode(raw) as Map<String, dynamic>;
    final typeChar = map['t'] as String?;
    if (typeChar == null) return null;

    if (typeChar == 'D') {
      // Validate CRC
      final payloadB64 = map['p'] as String?;
      if (payloadB64 == null) return null;
      final payloadBytes = base64.decode(payloadB64);
      final received = map['r'] as int?;
      if (received == null) return null;
      final computed = crc32Compute(payloadBytes);
      if (computed != received) return null; // CRC mismatch
    }
    return map;
  } catch (_) {
    return null;
  }
}

// ─── Tests ────────────────────────────────────────────────────────────────

void main() {
  group('SessionId', () {
    test('generated ID matches 8-char hex format', () {
      final id = sessionIdGenerate();
      expect(sessionIdIsValid(id), isTrue);
    });

    test('isValid rejects short IDs', () {
      expect(sessionIdIsValid('DEAD'), isFalse);
    });

    test('isValid rejects lowercase', () {
      expect(sessionIdIsValid('deadbeef'), isFalse);
    });

    test('isValid rejects non-hex chars', () {
      expect(sessionIdIsValid('DEADBEEG'), isFalse);
    });
  });

  group('Chunker', () {
    test('splits evenly divisible file correctly', () {
      final bytes = Uint8List.fromList(List.generate(2400, (i) => i % 256));
      final chunks = chunkSplit(bytes, chunkSize: 800);
      expect(chunks.length, 3);
      expect(chunks[0].length, 800);
      expect(chunks[1].length, 800);
      expect(chunks[2].length, 800);
    });

    test('last chunk is smaller for non-divisible sizes', () {
      final bytes = Uint8List.fromList(List.generate(1700, (i) => i % 256));
      final chunks = chunkSplit(bytes, chunkSize: 800);
      expect(chunks.length, 3); // ceil(1700/800) = 3
      expect(chunks[0].length, 800);
      expect(chunks[1].length, 800);
      expect(chunks[2].length, 100); // 1700 - 1600 = 100
    });

    test('single chunk for file smaller than chunkSize', () {
      final bytes = Uint8List.fromList(List.generate(300, (i) => i));
      final chunks = chunkSplit(bytes, chunkSize: 800);
      expect(chunks.length, 1);
      expect(chunks[0].length, 300);
    });

    test('reassemble reconstructs original bytes', () {
      final original = Uint8List.fromList(List.generate(2400, (i) => i % 256));
      final chunks = chunkSplit(original, chunkSize: 800);
      final map = <int, Uint8List>{};
      for (int i = 0; i < chunks.length; i++) {
        map[i] = chunks[i];
      }
      final reconstructed = chunkReassemble(map, chunks.length);
      expect(reconstructed, isNotNull);
      expect(reconstructed!.length, original.length);
      expect(reconstructed, equals(original));
    });

    test('reassemble returns null when chunk is missing', () {
      final original = Uint8List.fromList(List.generate(2400, (i) => i % 256));
      final chunks = chunkSplit(original, chunkSize: 800);
      final map = <int, Uint8List>{0: chunks[0], 2: chunks[2]}; // missing 1
      final result = chunkReassemble(map, chunks.length);
      expect(result, isNull);
    });

    test('reassemble out-of-order chunks produces correct output', () {
      final original = Uint8List.fromList(List.generate(1600, (i) => i % 256));
      final chunks = chunkSplit(original, chunkSize: 800);
      // Insert in reverse order
      final map = <int, Uint8List>{1: chunks[1], 0: chunks[0]};
      final reconstructed = chunkReassemble(map, chunks.length);
      expect(reconstructed, equals(original));
    });
  });

  group('CRC32', () {
    test('empty bytes produces known value', () {
      // CRC32 of empty = 0x00000000
      expect(crc32Compute([]), 0x00000000);
    });

    test('same bytes always produce same CRC', () {
      final data = [1, 2, 3, 4, 5, 6, 7, 8];
      expect(crc32Compute(data), equals(crc32Compute(data)));
    });

    test('different bytes produce different CRC', () {
      final a = [1, 2, 3];
      final b = [1, 2, 4]; // last byte differs
      expect(crc32Compute(a), isNot(equals(crc32Compute(b))));
    });

    test('bit flip is detected', () {
      final original = List.generate(100, (i) => i);
      final corrupted = List.from(original);
      corrupted[50] ^= 0x01; // flip one bit
      expect(crc32Compute(original), isNot(equals(crc32Compute(corrupted))));
    });
  });

  group('Frame serialization', () {
    test('META frame round-trips correctly', () {
      final qr = buildMetaQr(
        sessionId: 'DEADBEEF',
        fileName: 'test.pdf',
        fileSize: 102400,
        chunkCount: 128,
        sha256: 'abc123' * 10 + 'ab',
      );
      final parsed = parseFrame(qr);
      expect(parsed, isNotNull);
      expect(parsed!['t'], 'M');
      expect(parsed['s'], 'DEADBEEF');
      expect(parsed['fn'], 'test.pdf');
      expect(parsed['fs'], 102400);
      expect(parsed['cc'], 128);
    });

    test('DATA frame round-trips with CRC validation', () {
      final payload = Uint8List.fromList(List.generate(800, (i) => i % 256));
      final qr = buildDataQr(
        sessionId: 'DEADBEEF',
        chunkIndex: 42,
        chunkCount: 128,
        payload: payload,
      );
      final parsed = parseFrame(qr);
      expect(parsed, isNotNull);
      expect(parsed!['t'], 'D');
      expect(parsed['i'], 42);
    });

    test('corrupted DATA frame (bad CRC) is rejected', () {
      final payload = Uint8List.fromList(List.generate(800, (i) => i % 256));
      final qr = buildDataQr(
        sessionId: 'DEADBEEF',
        chunkIndex: 0,
        chunkCount: 1,
        payload: payload,
      );
      // Tamper with CRC value in JSON
      final map = jsonDecode(qr) as Map<String, dynamic>;
      map['r'] = (map['r'] as int) ^ 0xFFFFFFFF; // flip all bits
      final tampered = jsonEncode(map);

      final parsed = parseFrame(tampered);
      expect(parsed, isNull); // must be rejected
    });

    test('malformed JSON is rejected', () {
      expect(parseFrame('not json at all'), isNull);
      expect(parseFrame('{incomplete'), isNull);
      expect(parseFrame(''), isNull);
    });

    test('missing type field is rejected', () {
      expect(parseFrame('{"s":"DEADBEEF"}'), isNull);
    });

    test('unknown frame type is handled', () {
      final qr = jsonEncode({'t': 'X', 's': 'DEADBEEF'});
      // parseFrame returns the map regardless of unknown type
      // (type filtering is done by ScanController)
      final parsed = parseFrame(qr);
      // Since 'X' is not 'D', no CRC check — returns map
      expect(parsed, isNotNull);
    });
  });

  group('Full transfer simulation', () {
    test('100 KB file transfers correctly through protocol', () {
      // Simulate a 100 KB file
      final original = Uint8List.fromList(
        List.generate(100 * 1024, (i) => i % 256),
      );
      const sessionId = 'DEADBEEF';
      final chunks = chunkSplit(original, chunkSize: 800);
      final totalChunks = chunks.length;

      // Simulate sender generating frames
      final frames = <String>[];
      frames.add(buildMetaQr(
        sessionId: sessionId,
        fileName: 'test100kb.bin',
        fileSize: original.length,
        chunkCount: totalChunks,
        sha256: 'fakehash',
      ));
      for (int i = 0; i < totalChunks; i++) {
        frames.add(buildDataQr(
          sessionId: sessionId,
          chunkIndex: i,
          chunkCount: totalChunks,
          payload: chunks[i],
        ));
      }

      // Simulate receiver parsing frames
      final receivedChunks = <int, Uint8List>{};
      bool metaOk = false;

      for (final frame in frames) {
        final parsed = parseFrame(frame);
        if (parsed == null) continue;
        if (parsed['t'] == 'M') {
          metaOk = true;
          expect(parsed['cc'], totalChunks);
        } else if (parsed['t'] == 'D') {
          final idx = parsed['i'] as int;
          final payloadBytes = base64.decode(parsed['p'] as String);
          receivedChunks[idx] = Uint8List.fromList(payloadBytes);
        }
      }

      expect(metaOk, isTrue);
      expect(receivedChunks.length, totalChunks);

      final reconstructed = chunkReassemble(receivedChunks, totalChunks);
      expect(reconstructed, isNotNull);
      expect(reconstructed!.length, original.length);
      expect(reconstructed, equals(original));
    });

    test('10% frame loss is recovered by sender looping', () {
      final original = Uint8List.fromList(
        List.generate(10 * 1024, (i) => i % 256),
      );
      const sessionId = 'ABCD1234';
      final chunks = chunkSplit(original, chunkSize: 800);

      final receivedChunks = <int, Uint8List>{};

      // First pass: drop every 10th frame (simulate 10% loss)
      for (int i = 0; i < chunks.length; i++) {
        if (i % 10 == 0) continue; // simulate drop
        final qr = buildDataQr(
          sessionId: sessionId,
          chunkIndex: i,
          chunkCount: chunks.length,
          payload: chunks[i],
        );
        final parsed = parseFrame(qr)!;
        final payloadBytes = base64.decode(parsed['p'] as String);
        receivedChunks[i] = Uint8List.fromList(payloadBytes);
      }

      // Incomplete after first pass
      expect(receivedChunks.length, lessThan(chunks.length));

      // Second pass (sender loop): fill in missing
      for (int i = 0; i < chunks.length; i++) {
        if (receivedChunks.containsKey(i)) continue; // already got it
        final qr = buildDataQr(
          sessionId: sessionId,
          chunkIndex: i,
          chunkCount: chunks.length,
          payload: chunks[i],
        );
        final parsed = parseFrame(qr)!;
        final payloadBytes = base64.decode(parsed['p'] as String);
        receivedChunks[i] = Uint8List.fromList(payloadBytes);
      }

      expect(receivedChunks.length, chunks.length);
      final reconstructed = chunkReassemble(receivedChunks, chunks.length);
      expect(reconstructed, equals(original));
    });
  });
}

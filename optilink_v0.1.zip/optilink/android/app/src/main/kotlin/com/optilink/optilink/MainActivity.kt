package com.optilink.optilink

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

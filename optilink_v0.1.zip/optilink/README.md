# OptiLink v0.1

**Offline optical file transfer — no Wi-Fi, Bluetooth, or internet required.**

Data is transferred visually: the sender displays encoded QR frames on its screen; the receiver captures those frames with its camera and reconstructs the original file.

---

## Quick Start

### Prerequisites

- Flutter SDK ≥ 3.16.0 (Dart ≥ 3.2.0)
- Android SDK, target API 34, min API 21
- Two Android devices (or one device + Android emulator with camera passthrough)

### Install & Run

```bash
git clone <repo-url>
cd optilink
flutter pub get
flutter run
```

### Run Tests

```bash
flutter test
```

---

## Architecture

```
lib/
├── main.dart                   # App entry, navigation shell
│
├── protocol/                   # Pure Dart, no Flutter dependency
│   ├── frame.dart              # OptiLinkFrame — serialization & CRC32
│   ├── chunker.dart            # File split / reassemble
│   ├── manifest.dart           # SHA-256 manifest
│   └── session.dart            # Session ID generation
│
├── sender/
│   ├── frame_generator.dart    # Builds full frame sequence
│   ├── broadcast_controller.dart  # Timer-driven display loop
│   └── sender_screen.dart      # UI: file picker → QR display
│
├── receiver/
│   ├── scan_controller.dart    # Barcode → protocol state machine
│   └── receiver_screen.dart    # UI: camera → progress → file save
│
└── shared/
    └── transfer_state.dart     # ChangeNotifier state for both sides
```

---

## Protocol

### Wire Format

Every QR code contains a JSON string. Three frame types:

**META** (sent 3× at start of each loop):
```json
{"t":"M","s":"7F2A91C3","fn":"report.pdf","fs":102400,"cc":128,"h":"sha256hex"}
```

**DATA**:
```json
{"t":"D","s":"7F2A91C3","i":42,"c":128,"p":"base64payload","r":2863311530}
```
- `i` = chunk index (0-based)
- `p` = base64-encoded payload bytes
- `r` = CRC32 of raw payload bytes (frame validation)

**END** (sent 3× at end of each loop):
```json
{"t":"E","s":"7F2A91C3","cc":128}
```

### Transfer Flow

```
Sender                          Receiver
──────                          ────────
[META ×3]         ──────►       Lock session ID
                                Store filename, size, chunk count
[DATA_0]          ──────►       Store chunk 0
[DATA_1]          ──────►       Store chunk 1
...                             ...
[DATA_N]          ──────►       Store chunk N
[END ×3]          ──────►       If all chunks received: reassemble + verify
                                Else: keep scanning (sender loops)
[META ×3 again]   ──────►       (ignored — session already locked)
[DATA_0 again]    ──────►       (ignored — chunk 0 already received)
...
```

**Receiver joins at any point** — because sender loops continuously, the receiver catches all frames eventually.

### Integrity

- **CRC32** per DATA frame — corrupt frames are silently dropped
- **SHA-256** of the full reconstructed file — verified before saving

---

## Performance (v0.1)

| File Size | Chunks | Est. Time @ 6 FPS | Throughput |
|-----------|--------|--------------------|------------|
| 100 KB    | 128    | ~22 seconds        | ~4.5 KB/s  |
| 500 KB    | 640    | ~108 seconds       | ~4.6 KB/s  |
| 1 MB      | 1,311  | ~220 seconds       | ~4.7 KB/s  |
| 5 MB      | 6,554  | ~18 minutes        | ~4.7 KB/s  |

**6 FPS is conservative by design.** `mobile_scanner` decodes QR at 4–10 FPS depending on device and lighting. 6 FPS targets reliability over raw speed.

**Frame loss** is handled automatically: the sender loops infinitely; the receiver's duplicate detection ignores already-received chunks. 10% frame loss adds one extra loop pass.

---

## Key Engineering Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Chunk size | 800 bytes | 800 bytes → 1,139 char JSON → QR ver ~10 at L correction; fits any modern phone screen at readable size |
| Error correction | L (low) | Maximises data per QR; protocol-layer CRC32 handles corrupt frames instead |
| Frame rate | 6 FPS | Reliable across mid-range Android devices; easily tunable via `BroadcastController.frameIntervalMs` |
| Loop strategy | Infinite loop | Eliminates need for ACK in v0.1; receiver joins at any time |
| Session lock | First META wins | Prevents interference from other OptiLink transfers nearby |
| File size limit | 5 MB | 5 MB × QR ≈ 18 min; acceptable for proof-of-concept; scales with future optical encoding |
| Duplicate frames | Ignored (first write wins) | `Map.putIfAbsent` in ScanController; zero state management needed |

---

## Tuning

### Change frame rate

In `lib/sender/broadcast_controller.dart`:
```dart
static const int frameIntervalMs = 167; // 6 FPS
// → 125 for 8 FPS (if your test device handles it)
// → 250 for 4 FPS (for older/slower devices)
```

### Change chunk size

In `lib/protocol/chunker.dart`:
```dart
static const int defaultChunkSize = 800;
// → 600 for older QR scanners with smaller decode windows
// → 1200 if testing shows no decode issues (fewer frames needed)
```

---

## Roadmap

- **v0.2** — Adaptive frame rate: benchmark actual decode speed on first 10 frames and auto-tune
- **v0.3** — Color QR: separate R/G/B channel encoding (3× density)
- **v0.4** — Custom optical frames: full-screen data matrices, no QR library dependency
- **v0.5** — Bidirectional: receiver sends missing chunk IDs back to sender

---

## Testing

Protocol tests run without a device (pure Dart):
```bash
flutter test test/protocol_test.dart
```

All 21 protocol tests validate:
- Session ID format
- Chunker split/reassemble correctness
- CRC32 corruption detection
- Frame serialization round-trips
- Full 100 KB transfer simulation
- 10% frame loss recovery via looping

---

## Permissions

### Android
- `CAMERA` — QR scanning on receiver
- `WRITE_EXTERNAL_STORAGE` (API ≤ 28) — saving received files
- `WAKE_LOCK` — keeps screen on during sender broadcast

### iOS
- `NSCameraUsageDescription` — QR scanning
- `NSPhotoLibraryUsageDescription` — saving received files

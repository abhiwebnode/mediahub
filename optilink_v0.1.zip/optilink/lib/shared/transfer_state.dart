import 'dart:typed_data';
import 'package:flutter/foundation.dart';

/// Possible states for a sender transfer session
enum SenderStatus {
  idle,
  preparingFile,
  broadcasting,
  complete,
  error,
}

/// Possible states for a receiver transfer session
enum ReceiverStatus {
  idle,
  waitingForMeta,
  receivingData,
  complete,
  error,
}

/// ChangeNotifier for the Sender side
class SenderState extends ChangeNotifier {
  SenderStatus _status = SenderStatus.idle;
  String? _sessionId;
  String? _fileName;
  int _totalChunks = 0;
  int _currentFrameIndex = 0; // what frame we're currently displaying
  String? _errorMessage;
  DateTime? _startTime;
  DateTime? _endTime;

  // The QR string for the currently displayed frame
  String? _currentQrData;

  SenderStatus get status => _status;
  String? get sessionId => _sessionId;
  String? get fileName => _fileName;
  int get totalChunks => _totalChunks;
  int get currentFrameIndex => _currentFrameIndex;
  String? get errorMessage => _errorMessage;
  String? get currentQrData => _currentQrData;

  /// 0.0 to 1.0 progress; accounts for META + DATA + END frames
  double get progress {
    if (_totalChunks == 0) return 0;
    // Total frames = 1 META + N DATA + 1 END = N + 2
    // But we show progress as data chunks sent
    final dataProgress = _currentFrameIndex / _totalChunks;
    return dataProgress.clamp(0.0, 1.0);
  }

  String get elapsedLabel {
    if (_startTime == null) return '--';
    final elapsed = (_endTime ?? DateTime.now()).difference(_startTime!);
    final s = elapsed.inSeconds;
    if (s < 60) return '${s}s';
    return '${elapsed.inMinutes}m ${s % 60}s';
  }

  String get throughputLabel {
    if (_startTime == null || _totalChunks == 0 || _currentFrameIndex == 0) {
      return '--';
    }
    final elapsed =
        (_endTime ?? DateTime.now()).difference(_startTime!).inMilliseconds;
    if (elapsed == 0) return '--';
    // bytes transferred ≈ currentFrameIndex * chunkSize (800 bytes avg)
    final bytesApprox = _currentFrameIndex * 800;
    final kbps = (bytesApprox / elapsed * 1000 / 1024);
    return '${kbps.toStringAsFixed(1)} KB/s';
  }

  void startSession({
    required String sessionId,
    required String fileName,
    required int totalChunks,
  }) {
    _status = SenderStatus.broadcasting;
    _sessionId = sessionId;
    _fileName = fileName;
    _totalChunks = totalChunks;
    _currentFrameIndex = 0;
    _errorMessage = null;
    _startTime = DateTime.now();
    _endTime = null;
    notifyListeners();
  }

  void updateFrame(int frameIndex, String qrData) {
    _currentFrameIndex = frameIndex;
    _currentQrData = qrData;
    notifyListeners();
  }

  void complete() {
    _status = SenderStatus.complete;
    _currentFrameIndex = _totalChunks;
    _endTime = DateTime.now();
    notifyListeners();
  }

  void setError(String message) {
    _status = SenderStatus.error;
    _errorMessage = message;
    notifyListeners();
  }

  void reset() {
    _status = SenderStatus.idle;
    _sessionId = null;
    _fileName = null;
    _totalChunks = 0;
    _currentFrameIndex = 0;
    _errorMessage = null;
    _currentQrData = null;
    _startTime = null;
    _endTime = null;
    notifyListeners();
  }
}

/// ChangeNotifier for the Receiver side
class ReceiverState extends ChangeNotifier {
  ReceiverStatus _status = ReceiverStatus.idle;
  String? _sessionId;
  String? _fileName;
  int _fileSize = 0;
  int _totalChunks = 0;
  String? _sha256Expected;
  final Set<int> _receivedChunkIndices = {};
  int _duplicateFrames = 0;
  String? _errorMessage;
  Uint8List? _reconstructedFile;
  DateTime? _startTime;
  DateTime? _endTime;
  bool _scanning = false;

  ReceiverStatus get status => _status;
  String? get sessionId => _sessionId;
  String? get fileName => _fileName;
  int get fileSize => _fileSize;
  int get totalChunks => _totalChunks;
  String? get errorMessage => _errorMessage;
  Uint8List? get reconstructedFile => _reconstructedFile;
  bool get scanning => _scanning;
  int get receivedCount => _receivedChunkIndices.length;
  int get duplicateFrames => _duplicateFrames;

  Set<int> get missingChunks {
    final missing = <int>{};
    for (int i = 0; i < _totalChunks; i++) {
      if (!_receivedChunkIndices.contains(i)) missing.add(i);
    }
    return missing;
  }

  double get progress {
    if (_totalChunks == 0) return 0;
    return (_receivedChunkIndices.length / _totalChunks).clamp(0.0, 1.0);
  }

  String get elapsedLabel {
    if (_startTime == null) return '--';
    final elapsed = (_endTime ?? DateTime.now()).difference(_startTime!);
    final s = elapsed.inSeconds;
    if (s < 60) return '${s}s';
    return '${elapsed.inMinutes}m ${s % 60}s';
  }

  String get throughputLabel {
    if (_startTime == null || _receivedChunkIndices.isEmpty) return '--';
    final elapsed =
        (_endTime ?? DateTime.now()).difference(_startTime!).inMilliseconds;
    if (elapsed == 0) return '--';
    final bytesApprox = _receivedChunkIndices.length * 800;
    final kbps = (bytesApprox / elapsed * 1000 / 1024);
    return '${kbps.toStringAsFixed(1)} KB/s';
  }

  void startScanning() {
    _scanning = true;
    _status = ReceiverStatus.waitingForMeta;
    notifyListeners();
  }

  void onMetaReceived({
    required String sessionId,
    required String fileName,
    required int fileSize,
    required int totalChunks,
    required String sha256,
  }) {
    _sessionId = sessionId;
    _fileName = fileName;
    _fileSize = fileSize;
    _totalChunks = totalChunks;
    _sha256Expected = sha256;
    _receivedChunkIndices.clear();
    _duplicateFrames = 0;
    _status = ReceiverStatus.receivingData;
    _startTime = DateTime.now();
    _endTime = null;
    notifyListeners();
  }

  /// Returns true if this chunk was new (not a duplicate).
  bool onChunkReceived(int chunkIndex) {
    if (_receivedChunkIndices.contains(chunkIndex)) {
      _duplicateFrames++;
      notifyListeners();
      return false;
    }
    _receivedChunkIndices.add(chunkIndex);
    notifyListeners();
    return true;
  }

  void onComplete({
    required Uint8List file,
    required bool verified,
  }) {
    _reconstructedFile = file;
    _endTime = DateTime.now();
    _scanning = false;
    if (verified) {
      _status = ReceiverStatus.complete;
    } else {
      _status = ReceiverStatus.error;
      _errorMessage = 'SHA-256 checksum mismatch — file may be corrupted.';
    }
    notifyListeners();
  }

  void setError(String message) {
    _status = ReceiverStatus.error;
    _errorMessage = message;
    _scanning = false;
    notifyListeners();
  }

  String? get sha256Expected => _sha256Expected;

  void reset() {
    _status = ReceiverStatus.idle;
    _sessionId = null;
    _fileName = null;
    _fileSize = 0;
    _totalChunks = 0;
    _sha256Expected = null;
    _receivedChunkIndices.clear();
    _duplicateFrames = 0;
    _errorMessage = null;
    _reconstructedFile = null;
    _startTime = null;
    _endTime = null;
    _scanning = false;
    notifyListeners();
  }
}

import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:provider/provider.dart';
import '../shared/transfer_state.dart';
import '../widgets/stat_chip.dart';
import '../widgets/ol_colors.dart';
import 'frame_generator.dart';
import 'broadcast_controller.dart';

class SenderScreen extends StatefulWidget {
  const SenderScreen({super.key});

  @override
  State<SenderScreen> createState() => _SenderScreenState();
}

class _SenderScreenState extends State<SenderScreen>
    with WidgetsBindingObserver {
  BroadcastController? _controller;
  late SenderState _senderState;

  @override
  void initState() {
    super.initState();
    _senderState = SenderState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    _controller?.dispose();
    _senderState.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Pause broadcast when app goes to background
    if (state == AppLifecycleState.paused) {
      _controller?.stop();
    } else if (state == AppLifecycleState.resumed &&
        _senderState.status == SenderStatus.broadcasting) {
      _controller?.start();
    }
  }

  Future<void> _pickAndSend() async {
    // Pick file
    final result = await FilePicker.platform.pickFiles(
      type: FileType.any,
      withData: true,
      allowMultiple: false,
    );

    if (result == null || result.files.isEmpty) return;
    final picked = result.files.first;

    if (picked.bytes == null) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not read file bytes.')),
      );
      return;
    }

    final bytes = Uint8List.fromList(picked.bytes!);
    final fileName = picked.name;

    // Validate size — v0.1 limit: 5 MB
    if (bytes.length > 5 * 1024 * 1024) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('File too large. v0.1 limit is 5 MB.'),
          backgroundColor: OlColors.error,
        ),
      );
      return;
    }

    // Stop any existing broadcast
    _controller?.dispose();

    // Build generator and controller
    final generator = FrameGenerator.fromFile(
      fileName: fileName,
      fileBytes: bytes,
    );

    _controller = BroadcastController(
      generator: generator,
      state: _senderState,
    );

    // Start looping broadcast
    _controller!.start(loop: true);
  }

  void _stopSending() {
    _controller?.stop();
    _senderState.reset();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: _senderState,
      child: Consumer<SenderState>(
        builder: (context, state, _) => _buildBody(context, state),
      ),
    );
  }

  Widget _buildBody(BuildContext context, SenderState state) {
    return Scaffold(
      backgroundColor: OlColors.bg,
      appBar: AppBar(
        backgroundColor: OlColors.bg,
        elevation: 0,
        title: const Text(
          'Send',
          style: TextStyle(
            color: OlColors.textPrimary,
            fontWeight: FontWeight.w700,
            fontSize: 20,
          ),
        ),
        actions: [
          if (state.status == SenderStatus.broadcasting)
            TextButton(
              onPressed: _stopSending,
              child: const Text(
                'Stop',
                style: TextStyle(color: OlColors.error),
              ),
            ),
        ],
      ),
      body: switch (state.status) {
        SenderStatus.idle => _buildIdle(),
        SenderStatus.broadcasting => _buildBroadcasting(state),
        SenderStatus.complete => _buildComplete(state),
        SenderStatus.error => _buildError(state),
        SenderStatus.preparingFile => const Center(
          child: CircularProgressIndicator(color: OlColors.accent),
        ),
      },
    );
  }

  Widget _buildIdle() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(
                color: OlColors.accent.withOpacity(0.12),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.upload_rounded,
                size: 48,
                color: OlColors.accent,
              ),
            ),
            const SizedBox(height: 28),
            const Text(
              'Select a file to send',
              style: TextStyle(
                color: OlColors.textPrimary,
                fontSize: 22,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'The file will be encoded as optical QR frames.\nPoint the receiver\'s camera at this screen.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: OlColors.textSecondary,
                fontSize: 14,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 40),
            FilledButton.icon(
              onPressed: _pickAndSend,
              icon: const Icon(Icons.folder_open_rounded),
              label: const Text('Choose File'),
              style: FilledButton.styleFrom(
                backgroundColor: OlColors.accent,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(
                  horizontal: 32,
                  vertical: 16,
                ),
                textStyle: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'Max file size: 5 MB',
              style: TextStyle(color: OlColors.textSecondary, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBroadcasting(SenderState state) {
    final qrData = state.currentQrData;
    if (qrData == null) return const SizedBox.shrink();

    return Column(
      children: [
        // QR frame — maximize this for camera readability
        Expanded(
          child: Container(
            color: Colors.white, // white background essential for QR scanning
            padding: const EdgeInsets.all(16),
            child: Center(
              child: QrImageView(
                data: qrData,
                version: QrVersions.auto,
                errorCorrectionLevel: QrErrorCorrectLevel.L,
                // L = max data capacity at cost of error correction
                // We handle errors at protocol level with CRC32
                backgroundColor: Colors.white,
                foregroundColor: Colors.black,
                gapless: true,
              ),
            ),
          ),
        ),

        // Status bar
        Container(
          color: OlColors.surface,
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: const BoxDecoration(
                      color: OlColors.accent,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    state.fileName ?? '',
                    style: const TextStyle(
                      color: OlColors.textPrimary,
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                  const Spacer(),
                  Text(
                    'Session: ${state.sessionId ?? ''}',
                    style: const TextStyle(
                      color: OlColors.textSecondary,
                      fontSize: 11,
                      fontFamily: 'monospace',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              LinearProgressIndicator(
                value: state.progress,
                backgroundColor: OlColors.divider,
                valueColor: const AlwaysStoppedAnimation(OlColors.accent),
                minHeight: 4,
                borderRadius: BorderRadius.circular(2),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Text(
                    'Frame ${state.currentFrameIndex} / ${state.totalChunks}',
                    style: const TextStyle(
                      color: OlColors.textSecondary,
                      fontSize: 12,
                    ),
                  ),
                  const Spacer(),
                  StatChip(label: 'Speed', value: state.throughputLabel),
                  const SizedBox(width: 8),
                  StatChip(label: 'Time', value: state.elapsedLabel),
                ],
              ),
              const SizedBox(height: 4),
              const Text(
                '↻ Looping — receiver can join at any time',
                style: TextStyle(
                  color: OlColors.textSecondary,
                  fontSize: 11,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildComplete(SenderState state) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.check_circle_rounded,
              size: 72,
              color: OlColors.success,
            ),
            const SizedBox(height: 20),
            const Text(
              'Transfer Complete',
              style: TextStyle(
                color: OlColors.textPrimary,
                fontSize: 22,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              state.fileName ?? '',
              style: const TextStyle(
                color: OlColors.textSecondary,
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                StatChip(label: 'Avg speed', value: state.throughputLabel),
                const SizedBox(width: 12),
                StatChip(label: 'Duration', value: state.elapsedLabel),
              ],
            ),
            const SizedBox(height: 32),
            OutlinedButton(
              onPressed: _stopSending,
              style: OutlinedButton.styleFrom(
                foregroundColor: OlColors.accent,
                side: const BorderSide(color: OlColors.accent),
              ),
              child: const Text('Send Another File'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildError(SenderState state) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.error_outline_rounded,
              size: 72,
              color: OlColors.error,
            ),
            const SizedBox(height: 20),
            const Text(
              'Transfer Failed',
              style: TextStyle(
                color: OlColors.textPrimary,
                fontSize: 22,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              state.errorMessage ?? 'Unknown error.',
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: OlColors.textSecondary,
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 32),
            FilledButton(
              onPressed: _stopSending,
              style: FilledButton.styleFrom(
                backgroundColor: OlColors.accent,
              ),
              child: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }
}

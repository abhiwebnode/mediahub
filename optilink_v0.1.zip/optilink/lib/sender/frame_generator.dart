import 'dart:typed_data';
import '../protocol/frame.dart';
import '../protocol/chunker.dart';
import '../protocol/manifest.dart';
import '../protocol/session.dart';

/// Generates the complete sequence of QR data strings for a transfer.
/// Sequence: [META repeated x3] + [DATA_0..DATA_N] + [END repeated x3]
///
/// META is repeated 3 times to ensure the receiver gets it even if
/// the first couple of frames are missed at session start.
///
/// END is repeated 3 times to signal completion reliably.
class FrameGenerator {
  final String sessionId;
  final TransferManifest manifest;
  final List<Uint8List> chunks;
  late final List<String> _sequence;

  FrameGenerator._({
    required this.sessionId,
    required this.manifest,
    required this.chunks,
  }) {
    _sequence = _buildSequence();
  }

  factory FrameGenerator.fromFile({
    required String fileName,
    required Uint8List fileBytes,
  }) {
    final sessionId = SessionId.generate();
    final chunks = Chunker.split(fileBytes);
    final manifest = TransferManifest.fromFile(
      sessionId: sessionId,
      fileName: fileName,
      fileBytes: fileBytes,
      chunkCount: chunks.length,
    );
    return FrameGenerator._(
      sessionId: sessionId,
      manifest: manifest,
      chunks: chunks,
    );
  }

  /// Total number of frames to display (including META repeats and END repeats)
  int get totalFrames => _sequence.length;

  /// Number of data chunks
  int get dataChunkCount => chunks.length;

  /// Get the QR string for a given frame index
  String frameAt(int index) => _sequence[index];

  List<String> _buildSequence() {
    final seq = <String>[];

    // 3x META
    final metaFrame = OptiLinkFrame.meta(
      sessionId: manifest.sessionId,
      fileName: manifest.fileName,
      fileSize: manifest.fileSize,
      chunkCount: manifest.chunkCount,
      sha256: manifest.sha256Hex,
    );
    final metaQr = metaFrame.toQrString();
    for (int i = 0; i < 3; i++) {
      seq.add(metaQr);
    }

    // DATA frames
    for (int i = 0; i < chunks.length; i++) {
      final dataFrame = OptiLinkFrame.data(
        sessionId: manifest.sessionId,
        chunkIndex: i,
        chunkCount: chunks.length,
        payload: chunks[i],
      );
      seq.add(dataFrame.toQrString());
    }

    // 3x END
    final endFrame = OptiLinkFrame.end(
      sessionId: manifest.sessionId,
      chunkCount: chunks.length,
    );
    final endQr = endFrame.toQrString();
    for (int i = 0; i < 3; i++) {
      seq.add(endQr);
    }

    return seq;
  }
}

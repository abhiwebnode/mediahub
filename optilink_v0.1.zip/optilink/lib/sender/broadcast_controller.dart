import 'dart:async';
import 'frame_generator.dart';
import '../shared/transfer_state.dart';

/// Controls the timed broadcast loop.
/// Advances one frame every [frameIntervalMs] milliseconds.
///
/// Frame rate design decision:
///   Target 6 FPS (166ms interval) — conservative but reliable.
///   mobile_scanner typically decodes at 4–10 FPS in real conditions.
///   6 FPS gives the receiver enough time to decode each frame.
///   We're optimizing for RELIABILITY over raw speed in v0.1.
///
/// The receiver ignores duplicate frames (same chunk received twice),
/// so if the sender loops and replays frames, chunks already received
/// are simply discarded on the receiver side.
class BroadcastController {
  static const int frameIntervalMs = 167; // ~6 FPS

  final FrameGenerator generator;
  final SenderState state;

  Timer? _timer;
  int _frameIndex = 0;
  bool _looping = false;

  BroadcastController({
    required this.generator,
    required this.state,
  });

  void start({bool loop = true}) {
    _looping = loop;
    _frameIndex = 0;

    state.startSession(
      sessionId: generator.sessionId,
      fileName: generator.manifest.fileName,
      totalChunks: generator.dataChunkCount,
    );

    _displayFrame();
    _timer = Timer.periodic(
      const Duration(milliseconds: frameIntervalMs),
      _onTick,
    );
  }

  void _onTick(Timer _) {
    _frameIndex++;

    if (_frameIndex >= generator.totalFrames) {
      if (_looping) {
        // Loop back to first DATA frame (skip META re-send on loop)
        // Start from index 3 (after the 3 META frames)
        _frameIndex = 3;
      } else {
        stop();
        state.complete();
        return;
      }
    }
    _displayFrame();
  }

  void _displayFrame() {
    final qrData = generator.frameAt(_frameIndex);
    // Map sequence frame index to data chunk index for progress display
    // Frame 0,1,2 = META; frames 3..N+2 = DATA; last 3 = END
    final dataIdx = (_frameIndex - 3).clamp(0, generator.dataChunkCount);
    state.updateFrame(dataIdx, qrData);
  }

  void stop() {
    _timer?.cancel();
    _timer = null;
  }

  void dispose() {
    stop();
  }
}

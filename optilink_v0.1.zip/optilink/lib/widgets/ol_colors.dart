import 'package:flutter/material.dart';

/// OptiLink design tokens.
/// Dark theme: data transmission feels technical/secure.
/// Cyan accent for sender (emitting light).
/// Teal/green accent for receiver (capturing/confirmed).
class OlColors {
  OlColors._();

  // Base palette
  static const Color bg = Color(0xFF0D0F14);
  static const Color surface = Color(0xFF161920);
  static const Color surfaceElevated = Color(0xFF1E2230);
  static const Color divider = Color(0xFF2A2E3D);

  // Text
  static const Color textPrimary = Color(0xFFEEF0F8);
  static const Color textSecondary = Color(0xFF8A8FA8);

  // Sender accent — electric cyan
  static const Color accent = Color(0xFF00C2FF);

  // Receiver accent — verified green
  static const Color accent2 = Color(0xFF00D68F);

  // Semantic
  static const Color success = Color(0xFF00D68F);
  static const Color error = Color(0xFFFF4D6A);
  static const Color warning = Color(0xFFFFB020);
}

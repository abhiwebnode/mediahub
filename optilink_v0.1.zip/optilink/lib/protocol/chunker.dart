import 'dart:typed_data';
import 'dart:math';

/// Responsible for splitting file bytes into fixed-size chunks
/// and reassembling chunks back into file bytes.
///
/// Chunk size decision: 800 bytes
/// Rationale: QR error correction L supports ~2953 bytes binary,
/// but base64 encoding inflates payload ~33%, and JSON envelope
/// adds overhead. 800 raw bytes → ~1067 base64 chars + ~50 JSON
/// overhead = ~1117 chars, safely under QR capacity at high scan speed.
class Chunker {
  static const int defaultChunkSize = 800;

  /// Split [fileBytes] into a list of fixed-size chunks.
  static List<Uint8List> split(
    Uint8List fileBytes, {
    int chunkSize = defaultChunkSize,
  }) {
    final chunks = <Uint8List>[];
    int offset = 0;
    while (offset < fileBytes.length) {
      final end = min(offset + chunkSize, fileBytes.length);
      chunks.add(Uint8List.fromList(fileBytes.sublist(offset, end)));
      offset = end;
    }
    return chunks;
  }

  /// Reassemble chunks (indexed map) back into full file bytes.
  /// [chunks] maps chunkIndex → payload bytes.
  /// [totalChunks] is used to validate completeness.
  /// Returns null if any chunk is missing.
  static Uint8List? reassemble(
    Map<int, Uint8List> chunks,
    int totalChunks,
  ) {
    // Validate all chunks present
    for (int i = 0; i < totalChunks; i++) {
      if (!chunks.containsKey(i)) return null;
    }

    // Concatenate in order
    final buffer = BytesBuilder();
    for (int i = 0; i < totalChunks; i++) {
      buffer.add(chunks[i]!);
    }
    return buffer.toBytes();
  }

  /// Returns how many chunks a file of [fileSize] bytes produces.
  static int chunkCount(
    int fileSize, {
    int chunkSize = defaultChunkSize,
  }) {
    return (fileSize / chunkSize).ceil();
  }
}

import 'dart:convert';
import 'dart:typed_data';
import 'package:crc32/crc32.dart';

/// Frame types in the OptiLink v0.1 protocol
enum FrameType { meta, data, end }

/// Every QR frame displayed and decoded is an OptiLinkFrame.
/// Wire format (JSON string, base64-encoded payload for DATA frames):
///
/// META:
///   {"t":"M","s":"SESSION","fn":"file.pdf","fs":1048576,"cc":1024,"h":"sha256hex"}
///
/// DATA:
///   {"t":"D","s":"SESSION","i":42,"c":1024,"p":"base64payload","r":2863311530}
///   where r = CRC32 of the raw payload bytes
///
/// END:
///   {"t":"E","s":"SESSION","cc":1024}
class OptiLinkFrame {
  final FrameType type;
  final String sessionId;

  // META fields
  final String? fileName;
  final int? fileSize;
  final int? chunkCount;
  final String? sha256;

  // DATA fields
  final int? chunkIndex;
  final Uint8List? payload;
  final int? crc32Value;

  const OptiLinkFrame._({
    required this.type,
    required this.sessionId,
    this.fileName,
    this.fileSize,
    this.chunkCount,
    this.sha256,
    this.chunkIndex,
    this.payload,
    this.crc32Value,
  });

  /// Build a META frame
  factory OptiLinkFrame.meta({
    required String sessionId,
    required String fileName,
    required int fileSize,
    required int chunkCount,
    required String sha256,
  }) {
    return OptiLinkFrame._(
      type: FrameType.meta,
      sessionId: sessionId,
      fileName: fileName,
      fileSize: fileSize,
      chunkCount: chunkCount,
      sha256: sha256,
    );
  }

  /// Build a DATA frame
  factory OptiLinkFrame.data({
    required String sessionId,
    required int chunkIndex,
    required int chunkCount,
    required Uint8List payload,
  }) {
    final crc = CRC32.compute(payload);
    return OptiLinkFrame._(
      type: FrameType.data,
      sessionId: sessionId,
      chunkCount: chunkCount,
      chunkIndex: chunkIndex,
      payload: payload,
      crc32Value: crc,
    );
  }

  /// Build an END frame
  factory OptiLinkFrame.end({
    required String sessionId,
    required int chunkCount,
  }) {
    return OptiLinkFrame._(
      type: FrameType.end,
      sessionId: sessionId,
      chunkCount: chunkCount,
    );
  }

  /// Serialize to JSON string for QR encoding
  String toQrString() {
    final Map<String, dynamic> map = {'t': _typeChar, 's': sessionId};

    switch (type) {
      case FrameType.meta:
        map['fn'] = fileName;
        map['fs'] = fileSize;
        map['cc'] = chunkCount;
        map['h'] = sha256;
        break;
      case FrameType.data:
        map['i'] = chunkIndex;
        map['c'] = chunkCount;
        map['p'] = base64.encode(payload!);
        map['r'] = crc32Value;
        break;
      case FrameType.end:
        map['cc'] = chunkCount;
        break;
    }

    return jsonEncode(map);
  }

  String get _typeChar {
    switch (type) {
      case FrameType.meta:
        return 'M';
      case FrameType.data:
        return 'D';
      case FrameType.end:
        return 'E';
    }
  }

  /// Parse a QR string back into a frame. Returns null on any error.
  static OptiLinkFrame? fromQrString(String raw) {
    try {
      final map = jsonDecode(raw) as Map<String, dynamic>;
      final typeChar = map['t'] as String?;
      final sessionId = map['s'] as String?;

      if (typeChar == null || sessionId == null) return null;

      switch (typeChar) {
        case 'M':
          return OptiLinkFrame._(
            type: FrameType.meta,
            sessionId: sessionId,
            fileName: map['fn'] as String?,
            fileSize: map['fs'] as int?,
            chunkCount: map['cc'] as int?,
            sha256: map['h'] as String?,
          );

        case 'D':
          final payloadB64 = map['p'] as String?;
          if (payloadB64 == null) return null;
          final payloadBytes = base64.decode(payloadB64);
          final receivedCrc = map['r'] as int?;
          if (receivedCrc == null) return null;

          // Validate CRC32
          final computedCrc = CRC32.compute(payloadBytes);
          if (computedCrc != receivedCrc) {
            // CRC mismatch — corrupted frame, discard
            return null;
          }

          return OptiLinkFrame._(
            type: FrameType.data,
            sessionId: sessionId,
            chunkIndex: map['i'] as int?,
            chunkCount: map['c'] as int?,
            payload: Uint8List.fromList(payloadBytes),
            crc32Value: receivedCrc,
          );

        case 'E':
          return OptiLinkFrame._(
            type: FrameType.end,
            sessionId: sessionId,
            chunkCount: map['cc'] as int?,
          );

        default:
          return null;
      }
    } catch (_) {
      return null;
    }
  }

  @override
  String toString() =>
      'OptiLinkFrame(type=$type, session=$sessionId, chunk=$chunkIndex/$chunkCount)';
}

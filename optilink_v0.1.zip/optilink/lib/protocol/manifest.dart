import 'dart:convert';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';

/// Transfer manifest — describes the file being sent.
class TransferManifest {
  final String sessionId;
  final String fileName;
  final int fileSize;
  final int chunkCount;
  final String sha256Hex;

  const TransferManifest({
    required this.sessionId,
    required this.fileName,
    required this.fileSize,
    required this.chunkCount,
    required this.sha256Hex,
  });

  /// Compute SHA-256 of file bytes and build a manifest.
  factory TransferManifest.fromFile({
    required String sessionId,
    required String fileName,
    required Uint8List fileBytes,
    required int chunkCount,
  }) {
    final digest = sha256.convert(fileBytes);
    return TransferManifest(
      sessionId: sessionId,
      fileName: fileName,
      fileSize: fileBytes.length,
      chunkCount: chunkCount,
      sha256Hex: digest.toString(),
    );
  }

  /// Verify that [fileBytes] match the manifest's SHA-256.
  bool verify(Uint8List fileBytes) {
    final digest = sha256.convert(fileBytes);
    return digest.toString() == sha256Hex;
  }

  Map<String, dynamic> toJson() => {
    'session': sessionId,
    'filename': fileName,
    'filesize': fileSize,
    'chunkCount': chunkCount,
    'sha256': sha256Hex,
  };

  @override
  String toString() => jsonEncode(toJson());
}

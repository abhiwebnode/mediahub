import 'dart:math';

/// Generates and validates OptiLink session IDs.
/// Format: 8 uppercase hex chars, e.g. "7F2A91C3"
class SessionId {
  static final _rand = Random.secure();

  static String generate() {
    final bytes = List.generate(4, (_) => _rand.nextInt(256));
    return bytes.map((b) => b.toRadixString(16).padLeft(2, '0').toUpperCase()).join();
  }

  static bool isValid(String id) {
    return RegExp(r'^[0-9A-F]{8}$').hasMatch(id);
  }
}

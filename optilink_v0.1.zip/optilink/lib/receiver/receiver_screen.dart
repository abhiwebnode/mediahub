import 'dart:io';
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:path_provider/path_provider.dart';
import 'package:open_file/open_file.dart';
import 'package:provider/provider.dart';
import 'package:permission_handler/permission_handler.dart';
import '../shared/transfer_state.dart';
import '../widgets/stat_chip.dart';
import '../widgets/ol_colors.dart';
import 'scan_controller.dart';

class ReceiverScreen extends StatefulWidget {
  const ReceiverScreen({super.key});

  @override
  State<ReceiverScreen> createState() => _ReceiverScreenState();
}

class _ReceiverScreenState extends State<ReceiverScreen> {
  late ReceiverState _receiverState;
  late ScanController _scanController;
  MobileScannerController? _cameraController;
  bool _cameraPermissionGranted = false;
  bool _scannerActive = false;
  String? _savedFilePath;

  @override
  void initState() {
    super.initState();
    _receiverState = ReceiverState();
    _scanController = ScanController(state: _receiverState);
    _receiverState.addListener(_onStateChanged);
    _checkCameraPermission();
  }

  @override
  void dispose() {
    _receiverState.removeListener(_onStateChanged);
    _cameraController?.dispose();
    _receiverState.dispose();
    super.dispose();
  }

  void _onStateChanged() {
    if (_receiverState.status == ReceiverStatus.complete &&
        _receiverState.reconstructedFile != null) {
      _saveFile();
    }
  }

  Future<void> _checkCameraPermission() async {
    final status = await Permission.camera.status;
    if (status.isGranted) {
      setState(() => _cameraPermissionGranted = true);
    } else {
      final result = await Permission.camera.request();
      setState(() => _cameraPermissionGranted = result.isGranted);
    }
  }

  Future<void> _saveFile() async {
    final fileBytes = _receiverState.reconstructedFile;
    if (fileBytes == null) return;

    try {
      // Save to app documents directory first; user can share from there
      final dir = await getApplicationDocumentsDirectory();
      final fileName = _receiverState.fileName ?? 'optilink_received_file';
      final filePath = '${dir.path}/$fileName';
      final file = File(filePath);
      await file.writeAsBytes(fileBytes);

      if (!mounted) return;
      setState(() => _savedFilePath = filePath);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to save file: $e'),
          backgroundColor: OlColors.error,
        ),
      );
    }
  }

  void _startScanning() {
    if (!_cameraPermissionGranted) {
      _checkCameraPermission();
      return;
    }

    _scanController.reset();
    setState(() {
      _savedFilePath = null;
      _scannerActive = true;
    });

    _cameraController = MobileScannerController(
      detectionSpeed: DetectionSpeed.noDuplicates,
      facing: CameraFacing.back,
      formats: [BarcodeFormat.qrCode],
      // Lock focus is set via autoStart — controller handles focus
    );

    _receiverState.startScanning();
  }

  void _stopScanning() {
    _cameraController?.stop();
    _cameraController?.dispose();
    _cameraController = null;
    setState(() => _scannerActive = false);
    _receiverState.reset();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: _receiverState,
      child: Consumer<ReceiverState>(
        builder: (context, state, _) => _buildBody(context, state),
      ),
    );
  }

  Widget _buildBody(BuildContext context, ReceiverState state) {
    return Scaffold(
      backgroundColor: OlColors.bg,
      appBar: AppBar(
        backgroundColor: OlColors.bg,
        elevation: 0,
        title: const Text(
          'Receive',
          style: TextStyle(
            color: OlColors.textPrimary,
            fontWeight: FontWeight.w700,
            fontSize: 20,
          ),
        ),
        actions: [
          if (_scannerActive && state.status != ReceiverStatus.complete)
            TextButton(
              onPressed: _stopScanning,
              child: const Text('Stop', style: TextStyle(color: OlColors.error)),
            ),
        ],
      ),
      body: switch (state.status) {
        ReceiverStatus.idle => _buildIdle(),
        ReceiverStatus.waitingForMeta => _buildScanner(state),
        ReceiverStatus.receivingData => _buildScanner(state),
        ReceiverStatus.complete => _buildComplete(state),
        ReceiverStatus.error => _buildError(state),
      },
    );
  }

  Widget _buildIdle() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(
                color: OlColors.accent2.withOpacity(0.12),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.qr_code_scanner_rounded,
                size: 48,
                color: OlColors.accent2,
              ),
            ),
            const SizedBox(height: 28),
            const Text(
              'Ready to receive',
              style: TextStyle(
                color: OlColors.textPrimary,
                fontSize: 22,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'Point your camera at the sender\'s screen.\nThe transfer starts automatically.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: OlColors.textSecondary,
                fontSize: 14,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 40),
            FilledButton.icon(
              onPressed:
                  _cameraPermissionGranted ? _startScanning : _checkCameraPermission,
              icon: const Icon(Icons.camera_alt_rounded),
              label: Text(
                _cameraPermissionGranted ? 'Start Scanning' : 'Grant Camera Access',
              ),
              style: FilledButton.styleFrom(
                backgroundColor: OlColors.accent2,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(
                  horizontal: 32,
                  vertical: 16,
                ),
                textStyle: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildScanner(ReceiverState state) {
    final cameraCtrl = _cameraController;
    if (cameraCtrl == null) return const SizedBox.shrink();

    return Column(
      children: [
        // Camera viewfinder
        Expanded(
          child: Stack(
            children: [
              MobileScanner(
                controller: cameraCtrl,
                onDetect: (capture) {
                  for (final barcode in capture.barcodes) {
                    final raw = barcode.rawValue;
                    if (raw != null) {
                      _scanController.onBarcodeDetected(raw);
                    }
                  }
                },
              ),
              // Scan overlay
              _buildScanOverlay(state),
            ],
          ),
        ),

        // Status panel
        _buildStatusPanel(state),
      ],
    );
  }

  Widget _buildScanOverlay(ReceiverState state) {
    final isWaiting = state.status == ReceiverStatus.waitingForMeta;
    return Positioned.fill(
      child: Column(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(
                  color: isWaiting
                      ? Colors.white.withOpacity(0.5)
                      : OlColors.accent2,
                  width: 2,
                ),
              ),
              child: isWaiting
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const SizedBox(
                            width: 32,
                            height: 32,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.black54,
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: const Text(
                              'Waiting for sender…',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                  : null,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusPanel(ReceiverState state) {
    final isWaiting = state.status == ReceiverStatus.waitingForMeta;
    return Container(
      color: OlColors.surface,
      padding: const EdgeInsets.all(16),
      child: isWaiting
          ? const Text(
              'Point camera at sender screen — transfer starts automatically',
              style: TextStyle(
                color: OlColors.textSecondary,
                fontSize: 13,
              ),
              textAlign: TextAlign.center,
            )
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(
                      Icons.download_rounded,
                      size: 16,
                      color: OlColors.accent2,
                    ),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        state.fileName ?? '',
                        style: const TextStyle(
                          color: OlColors.textPrimary,
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Text(
                      '${state.receivedCount}/${state.totalChunks} chunks',
                      style: const TextStyle(
                        color: OlColors.textSecondary,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                LinearProgressIndicator(
                  value: state.progress,
                  backgroundColor: OlColors.divider,
                  valueColor: const AlwaysStoppedAnimation(OlColors.accent2),
                  minHeight: 4,
                  borderRadius: BorderRadius.circular(2),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Text(
                      '${(state.progress * 100).toStringAsFixed(0)}%',
                      style: const TextStyle(
                        color: OlColors.textSecondary,
                        fontSize: 12,
                      ),
                    ),
                    const Spacer(),
                    StatChip(label: 'Speed', value: state.throughputLabel),
                    const SizedBox(width: 8),
                    StatChip(label: 'Time', value: state.elapsedLabel),
                  ],
                ),
                if (state.duplicateFrames > 0) ...[
                  const SizedBox(height: 4),
                  Text(
                    '${state.duplicateFrames} duplicate frames discarded',
                    style: const TextStyle(
                      color: OlColors.textSecondary,
                      fontSize: 11,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ],
              ],
            ),
    );
  }

  Widget _buildComplete(ReceiverState state) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.verified_rounded,
              size: 72,
              color: OlColors.success,
            ),
            const SizedBox(height: 20),
            const Text(
              'File Received',
              style: TextStyle(
                color: OlColors.textPrimary,
                fontSize: 24,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              state.fileName ?? '',
              style: const TextStyle(
                color: OlColors.textSecondary,
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 6),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.check_circle_outline_rounded,
                  size: 14,
                  color: OlColors.success,
                ),
                const SizedBox(width: 4),
                const Text(
                  'SHA-256 verified',
                  style: TextStyle(
                    color: OlColors.success,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                StatChip(label: 'Chunks', value: '${state.totalChunks}'),
                const SizedBox(width: 12),
                StatChip(label: 'Speed', value: state.throughputLabel),
                const SizedBox(width: 12),
                StatChip(label: 'Time', value: state.elapsedLabel),
              ],
            ),
            const SizedBox(height: 32),
            if (_savedFilePath != null) ...[
              FilledButton.icon(
                onPressed: () => OpenFile.open(_savedFilePath),
                icon: const Icon(Icons.open_in_new_rounded),
                label: const Text('Open File'),
                style: FilledButton.styleFrom(
                  backgroundColor: OlColors.accent2,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 28,
                    vertical: 14,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                _savedFilePath!.split('/').last,
                style: const TextStyle(
                  color: OlColors.textSecondary,
                  fontSize: 11,
                  fontFamily: 'monospace',
                ),
              ),
              const SizedBox(height: 16),
            ],
            OutlinedButton(
              onPressed: () {
                _scanController.reset();
                setState(() {
                  _scannerActive = false;
                  _savedFilePath = null;
                });
              },
              style: OutlinedButton.styleFrom(
                foregroundColor: OlColors.accent2,
                side: const BorderSide(color: OlColors.accent2),
              ),
              child: const Text('Receive Another File'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildError(ReceiverState state) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.error_outline_rounded,
              size: 72,
              color: OlColors.error,
            ),
            const SizedBox(height: 20),
            const Text(
              'Transfer Failed',
              style: TextStyle(
                color: OlColors.textPrimary,
                fontSize: 22,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              state.errorMessage ?? 'Unknown error.',
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: OlColors.textSecondary,
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 32),
            FilledButton(
              onPressed: () {
                _scanController.reset();
                setState(() {
                  _scannerActive = false;
                  _savedFilePath = null;
                });
                _startScanning();
              },
              style: FilledButton.styleFrom(backgroundColor: OlColors.accent2),
              child: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }
}

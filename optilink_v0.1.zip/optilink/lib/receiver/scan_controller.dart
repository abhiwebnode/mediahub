import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import '../protocol/frame.dart';
import '../protocol/chunker.dart';
import '../shared/transfer_state.dart';

/// Processes decoded QR barcodes and drives the ReceiverState machine.
///
/// Design decisions:
/// - Stateful: holds chunk map in memory during transfer
/// - Session-locked: once a META frame is received, only frames with
///   the same session ID are accepted
/// - Idempotent chunk receipt: duplicate chunks are ignored
/// - SHA-256 verified inline after reassembly
class ScanController {
  final ReceiverState state;

  String? _lockedSessionId;
  final Map<int, Uint8List> _chunks = {};
  bool _metaReceived = false;
  bool _complete = false;

  ScanController({required this.state});

  /// Called by the camera scanner for every successfully decoded QR string.
  void onBarcodeDetected(String raw) {
    if (_complete) return;

    final frame = OptiLinkFrame.fromQrString(raw);
    if (frame == null) return; // unparseable or CRC failed

    // Enforce session lock
    if (_lockedSessionId != null && frame.sessionId != _lockedSessionId) {
      return; // belongs to a different transfer
    }

    switch (frame.type) {
      case FrameType.meta:
        _handleMeta(frame);
        break;
      case FrameType.data:
        _handleData(frame);
        break;
      case FrameType.end:
        _handleEnd(frame);
        break;
    }
  }

  void _handleMeta(OptiLinkFrame frame) {
    if (_metaReceived) return; // already got it, ignore repeats

    if (frame.fileName == null ||
        frame.fileSize == null ||
        frame.chunkCount == null ||
        frame.sha256 == null) {
      state.setError('Received malformed META frame.');
      return;
    }

    _lockedSessionId = frame.sessionId;
    _metaReceived = true;

    state.onMetaReceived(
      sessionId: frame.sessionId,
      fileName: frame.fileName!,
      fileSize: frame.fileSize!,
      totalChunks: frame.chunkCount!,
      sha256: frame.sha256!,
    );
  }

  void _handleData(OptiLinkFrame frame) {
    if (!_metaReceived) return;
    if (frame.chunkIndex == null || frame.payload == null) return;

    final idx = frame.chunkIndex!;
    if (idx < 0 || idx >= state.totalChunks) return;

    // Store chunk (idempotent — first write wins)
    _chunks.putIfAbsent(idx, () => frame.payload!);
    state.onChunkReceived(idx);
  }

  void _handleEnd(OptiLinkFrame frame) {
    if (!_metaReceived || _complete) return;

    // Not all chunks received yet — sender loops, keep scanning
    if (_chunks.length < state.totalChunks) return;

    // Reassemble
    final fileBytes = Chunker.reassemble(_chunks, state.totalChunks);
    if (fileBytes == null) {
      state.setError('File reassembly failed — missing chunks.');
      return;
    }

    // SHA-256 verification
    final digest = sha256.convert(fileBytes);
    final verified = digest.toString() == state.sha256Expected;

    _complete = true;
    state.onComplete(file: fileBytes, verified: verified);
  }

  void reset() {
    _lockedSessionId = null;
    _chunks.clear();
    _metaReceived = false;
    _complete = false;
    state.reset();
  }
}
